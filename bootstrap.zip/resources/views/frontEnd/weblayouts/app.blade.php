@include('frontEnd.weblayouts.head')
@include('frontEnd.weblayouts.header')
@yield('content')
@include('frontEnd.weblayouts.footer')
