<?php echo $__env->make('frontEnd.weblayouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontEnd.weblayouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('frontEnd.weblayouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/frontEnd/weblayouts/app.blade.php ENDPATH**/ ?>