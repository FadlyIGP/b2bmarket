  <footer id="footer">
    <div class="footer">
      <p class="footer-text-left">

        <a href="#" id="GFG" class="menu icon-style">
          <i class="fa-solid fa-house-user"></i>
        </a>

        <a href="<?php echo e(url('/carts')); ?>" id="GFG" class="menu icon-style"> 
          <i class="fa-solid fa-cart-plus"></i>
          <span class='badge badge-warning' id='lblCartCount'><?php echo e(\Session::get('countingcart')); ?> </span>    
        </a>

        <a href="#" id="GFG" class="menu icon-style">
          <i class="fa-solid fa-heart"></i>
          <span class='badge badge-warning' id='lblCartCount'> 5 </span>
        </a> 

        <a href="#" id="GFG" class="menu icon-style">
          <i class="fa-solid fa-money-bill-1-wave"></i>
        </a>

        <a href="#" id="GFG" class="menu icon-style">
          <i class="fa-solid fa-comment-dots"></i>
          <span class='badge badge-warning' id='lblCartCount'> 5 </span>
        </a>

      </p>
    </div>
  </footer>

  <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>

  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/owl-carousel.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/animation.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/imagesloaded.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/popup.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script><?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/frontEnd/weblayouts/footer.blade.php ENDPATH**/ ?>