

<?php $__env->startSection('title'); ?>
    Dashboard
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="active">Dashboard</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
    
</style>
<!-- Small boxes (Stat box) -->
<div class="row">
    <div class="col-lg-4 col-xs-6" >
        <!-- small box -->
        <div class="small-box bg-aqua" style="border-radius: 5px;">
            <div class="inner">
                <h3>150</h3>
                <p>Products</p>
            </div>
            <div class="icon">
                <i class="fa fa-dropbox"></i>
            </div>
            <a href="#" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-green" style="border-radius: 5px;">
            <div class="inner">
                <h3>1203</h3>
                <p>Transaction</p>
            </div>
            <div class="icon">
                <i class="fa fa-cart-arrow-down"></i>
            </div>
            <a href="#" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->    
    <div class="col-lg-4 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-red" style="border-radius: 5px;">
            <div class="inner">
                <h3>5</h3>
                <p>Contract</p>
            </div>
            <div class="icon" >
                <i class="fa fa-stumbleupon-circle"></i>
            </div>
            <a href="#" class="small-box-footer">More Info <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
</div>
<!-- /.row -->
<!-- Main row -->
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border" style="border-radius: 20px;">
                <h3 class="box-title">Statistic Transaction</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="border-radius: 20px;">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="chart" style="height: 300px">
                            <!-- Sales Chart Canvas -->
                           <canvas id="myChart" style="width:50%;height: 300px"></canvas>
                        </div>
                        <!-- /.chart-responsive -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>
<!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- ChartJS -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/home.blade.php ENDPATH**/ ?>