<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1.0
    </div>
    <strong>Copyright &copy; JualinAja.net <?php echo e(date('Y')); ?> <a href="/"></a>.</strong> All rights
    reserved.
</footer><?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/layouts/footer.blade.php ENDPATH**/ ?>