

<?php $__env->startSection('title'); ?>
List Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>

<li class="active">List Category</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-lg-12">
		<div class="box">
			<div class="box-header with-border">

				<a href="<?php echo e(url('/productcategories/create')); ?>" class="btn btn-info btn-xs btn-flat" style="border-radius: 5px"><i class="fa fa-plus-circle"></i>&nbsp; Add Category</a>
			</div>
			<div class="box-body table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Address</th>
							<th>City</th>
						</tr>
					</thead>
					<tbody id="tblbody"></tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

    $(document).ready( function () {
    	$.ajax({
    		url: "/sendtoajax", 
    		type: "GET",          
    		cache: true, 
    		success: function(response){
    			$.each(data,function(data){ 
    				$("#exampleid tbody").append(
    					"<tr>"
    					+"<td>"+data.id+"</td>"
    					+"<td>"+data.name+"</td>"
    					+"</tr>" )
    			})
    		}

    	});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/productcategory/listajax.blade.php ENDPATH**/ ?>