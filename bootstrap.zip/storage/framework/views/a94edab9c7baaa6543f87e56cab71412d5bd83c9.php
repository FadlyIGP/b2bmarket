

<?php $__env->startSection('title'); ?>
List Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>

<li class="active">List Category</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-lg-12">
		<div class="box">
			<div class="box-header with-border">

				<a href="<?php echo e(url('/productcategories/create')); ?>" class="btn btn-info btn-xs btn-flat" style="border-radius: 5px"><i class="fa fa-plus-circle"></i>&nbsp; Add Category</a>
			</div>
			<div class="box-body table-responsive">
				<table class="table table-bordered" id="table_id">
					<thead class=" text-primary">
						<tr>
							<th width="4%">No</th>
							<th scope="col">Name</th>
							<th scope="col">Company Name</th>
							<th scope="col">Created_at</th>
							<th scope="col">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $categorylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td width="4%"></td>
							<td><?php echo e($list['name']); ?></td>
							<td><?php echo e($list['company_name']); ?></td>
							<td><?php echo e(date("d-M-Y",strtotime($list['created_at']))); ?></td>
							<td>
								<?php echo Form::open(); ?>

								<a href="#" value="" title="Hapus Data" class="btn btn-xs btn-info btn-info"><i class="fa fa-pencil"></i>
								</a>
								<button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('yakin ingin menghapus data ini?')">
									<i class="fa fa-trash"></i>
								</button>

								<?php echo Form::close(); ?>

							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
	//**datatable**//
	$(document).ready( function () {
		$('#table_id').DataTable({
			"columnDefs": [{
				"searchable": false,
				"orderable": false,
				"targets": 0,
				render: function (data, type, row, meta) {
					return meta.row + meta.settings._iDisplayStart + 1;
				}
			}],
			"aLengthMenu": [[5, 10, 25, 50, 75, 100, -1], [5, 10, 25, 50, 75, 100, "All"]],
			"iDisplayLength": 10,
			responsive: true,
		});

	});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\LaraProject\SkripsiProject\b2bmarket\resources\views/productcategory/productcategorylist.blade.php ENDPATH**/ ?>