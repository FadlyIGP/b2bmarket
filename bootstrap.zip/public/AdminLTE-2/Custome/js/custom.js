$(document).ready(function () {
// add selectize to select element
	$('.js-selectize').selectize({
	sortField: 'text'
	});
});
